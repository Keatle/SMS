DROP DATABASE IF EXISTS managementsociety;
CREATE DATABASE managementsociety;
USE managementsociety;

CREATE TABLE user(
    userID INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    studentN VARCHAR(10) NOT NULL,
    name VARCHAR(255) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE userRole (
    roleID INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    roleName VARCHAR(50) NOT NULL
);

CREATE TABLE userRoleAssignment (
    assignmentID INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    userID INT NOT NULL,
    roleID INT NOT NULL,
    FOREIGN KEY (userID) REFERENCES user(userID),
    FOREIGN KEY (roleID) REFERENCES userRole(roleID)
);

CREATE TABLE society (
    societyID INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    societyName VARCHAR(255) NOT NULL,
    societyDescription TEXT NOT NULL,
    department TEXT NOT NULL,
    societyIcon TEXT NOT NULL,
    societyConstitution TEXT NOT NULL,
    societyExecutiveList TEXT NOT NULL,
    societyPetitionList TEXT NOT NULL,
    societyYearPlan TEXT NOT NULL,
    societyBudget TEXT NOT NULL,
    societyPayment TEXT NOT NULL,
    status TEXT NOT NULL
);

CREATE TABLE societyExecutive (
    societyExecutiveID INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    societyID INT NOT NULL,
    userID INT NOT NULL,
    roleID INT NOT NULL,
    FOREIGN KEY (societyID) REFERENCES society(societyID),
    FOREIGN KEY (userID) REFERENCES user(userID),
    FOREIGN KEY (roleID) REFERENCES userRole(roleID)
);

CREATE TABLE societyMember (
    membershipID INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    societyID INT NOT NULL,
    userID INT NOT NULL,
    FOREIGN KEY (societyID) REFERENCES society(societyID),
    FOREIGN KEY (userID) REFERENCES user(userID)
);

CREATE TABLE event (
    eventID INT AUTO_INCREMENT PRIMARY KEY,
    societyID INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    eventDate DATETIME NOT NULL,
    eventLocation VARCHAR(255) NOT NULL,
    description VARCHAR(255) NOT NULL,
    eventType VARCHAR(255) NOT NULL,
    preferredVenue VARCHAR(255) NOT NULL,
    preferredTransport VARCHAR(255) NOT NULL,
    eventAmount FLOAT(53) NOT NULL,
    FOREIGN KEY (societyID) REFERENCES society(societyID)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE agenda (
    agendaID INT NOT NULL AUTO_INCREMENT,
    societyID INT NOT NULL,
    meetingName VARCHAR(100) NOT NULL,
    meetingDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    meetingVenue VARCHAR(100) DEFAULT NULL,
    meetingAgenda TEXT,
    PRIMARY KEY (agendaID),
    KEY societyID (societyID),
    CONSTRAINT agenda_ibfk_1 FOREIGN KEY (societyID) REFERENCES society(societyID)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE minutes (
    minutesID INT NOT NULL AUTO_INCREMENT,
    societyID INT NOT NULL,
    motion VARCHAR(255) NOT NULL,
    PRIMARY KEY (minutesID),
    FOREIGN KEY (societyID) REFERENCES society(societyID)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE attendanceCode (
    codeID INT AUTO_INCREMENT PRIMARY KEY,
    eventID INT NOT NULL,
    code VARCHAR(255) NOT NULL UNIQUE,
    FOREIGN KEY (eventID) REFERENCES event(eventID)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE eventAttendance (
    eventAttendanceID INT AUTO_INCREMENT NOT NULL,
    eventID INT NOT NULL,
    memberID INT NOT NULL,
    PRIMARY KEY (eventAttendanceID),
    FOREIGN KEY (eventID) REFERENCES event(eventID),
    FOREIGN KEY (memberID) REFERENCES user(userID)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
