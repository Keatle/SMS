DROP DATABASE IF EXISTS managementsociety;
CREATE DATABASE managementsociety;
USE managementsociety;

-- Create User table first
CREATE TABLE User (
    userID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    PRIMARY KEY (userID)
);

-- Create Admin table
CREATE TABLE Admin (
    adminID VARCHAR(30) NOT NULL,
    yearApointed DATETIME NOT NULL,
    userID VARCHAR(30) NOT NULL,
    PRIMARY KEY (adminID),
    FOREIGN KEY (userID) REFERENCES User(userID)
);

-- Create SocietyLeader table
CREATE TABLE SocietyLeader (
    societyLeaderID VARCHAR(30) NOT NULL,
    userID VARCHAR(30) NOT NULL,
    position VARCHAR(255) NOT NULL,
    yearAppointed DATETIME NOT NULL,
    PRIMARY KEY (societyLeaderID),
    FOREIGN KEY (userID) REFERENCES User(userID)
);

-- Create Chairperson table
CREATE TABLE Chairperson (
    chairpersonID VARCHAR(30) NOT NULL,
    societyLeaderID VARCHAR(30) NOT NULL,
    PRIMARY KEY (chairpersonID),
    FOREIGN KEY (societyLeaderID) REFERENCES SocietyLeader(societyLeaderID)
);

-- Create Secretary table
CREATE TABLE Secretary (
    secretaryID VARCHAR(30) NOT NULL,
    societyLeaderID VARCHAR(30) NOT NULL,
    PRIMARY KEY (secretaryID),
    FOREIGN KEY (societyLeaderID) REFERENCES SocietyLeader(societyLeaderID)
);

-- Continue with other tables ensuring correct order
CREATE TABLE Application (
    applicationID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    societyName VARCHAR(255) NOT NULL,
    numMembers INT NOT NULL,
    applicationDate DATETIME NOT NULL,
    status VARCHAR(255) NOT NULL,
    ACTIVE BIT NOT NULL,
    chairpersonID VARCHAR(30) NOT NULL,
    PRIMARY KEY (applicationID)
);

CREATE TABLE CommiteeList (
    commiteeListID VARCHAR(30) NOT NULL,
    status VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    active BIT NOT NULL,
    minutes INT NOT NULL,
    chairpersonID VARCHAR(30) NOT NULL,
    PRIMARY KEY (commiteeListID),
    FOREIGN KEY (chairpersonID) REFERENCES Chairperson(chairpersonID)
);

CREATE TABLE Department (
    departmentID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    totalSocieties INT NOT NULL,
    PRIMARY KEY (departmentID)
);

CREATE TABLE Event (
    eventID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    eventDate DATETIME NOT NULL,
    eventLocation VARCHAR(255) NOT NULL,
    Description VARCHAR(255) NOT NULL,
    eventType VARCHAR(255) NOT NULL,
    PRIMARY KEY (eventID)
);

CREATE TABLE EventAttendance (
    eventAttendanceID VARCHAR(30) NOT NULL,
    eventID VARCHAR(30) NOT NULL,
    walk_in INT NOT NULL,
    noRSVP INT NOT NULL,
    PRIMARY KEY (eventAttendanceID),
    FOREIGN KEY (eventID) REFERENCES Event(eventID)
);

CREATE TABLE Treasure (
    treasureID VARCHAR(30) NOT NULL,
    societyLeaderID VARCHAR(30) NOT NULL,
    PRIMARY KEY (treasureID),
    FOREIGN KEY (societyLeaderID) REFERENCES SocietyLeader(societyLeaderID)
);

CREATE TABLE EventBudget (
    eventBudgetID VARCHAR(30) NOT NULL,
    treasureID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    totalCost FLOAT(53) NOT NULL,
    PRIMARY KEY (eventBudgetID),
    FOREIGN KEY (treasureID) REFERENCES Treasure(treasureID)
);

CREATE TABLE Meeting (
    meetingID VARCHAR(30) NOT NULL,
    secretaryID VARCHAR(30) NOT NULL,
    meetingDate DATETIME NOT NULL,
    content TEXT NOT NULL,
    PRIMARY KEY (meetingID),
    FOREIGN KEY (secretaryID) REFERENCES Secretary(secretaryID)
);

CREATE TABLE ProposalStatus (
    proposalStatusID VARCHAR(30) NOT NULL,
    societyLeaderID VARCHAR(30) NOT NULL,
    status VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    PRIMARY KEY (proposalStatusID),
    FOREIGN KEY (societyLeaderID) REFERENCES SocietyLeader(societyLeaderID)
);

CREATE TABLE Minutes (
    minutesID INT NOT NULL,
    secretaryID VARCHAR(30) NOT NULL,
    proposalStatusID VARCHAR(30) NOT NULL,
    motion VARCHAR(255) NOT NULL,
    proposalReason VARCHAR(255) NOT NULL,
    PRIMARY KEY (minutesID),
    FOREIGN KEY (secretaryID) REFERENCES Secretary(secretaryID),
    FOREIGN KEY (proposalStatusID) REFERENCES ProposalStatus(proposalStatusID)
);

CREATE TABLE ProposalRejectionReason (
    proposalRejectionReasonID VARCHAR(30) NOT NULL,
    name VARCHAR(30) NOT NULL,
    minutes VARCHAR(30) NOT NULL,
    PRIMARY KEY (proposalRejectionReasonID)
);

CREATE TABLE Society (
    societyID VARCHAR(30) NOT NULL,
    departmentID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    totalMembers INT NOT NULL,
    totalEvents INT NOT NULL,
    active BIT NOT NULL,
    yearRegistered DATETIME NOT NULL,
    PRIMARY KEY (societyID),
    FOREIGN KEY (departmentID) REFERENCES Department(departmentID)
);

CREATE TABLE SocietyBudget (
    societyBudgetID VARCHAR(30) NOT NULL,
    treasureID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    totalCost FLOAT(53) NOT NULL,
    PRIMARY KEY (societyBudgetID),
    FOREIGN KEY (treasureID) REFERENCES Treasure(treasureID)
);

CREATE TABLE Member (
    memberID VARCHAR(30) NOT NULL,
    societyID VARCHAR(30) NOT NULL,
    eventAttendanceID VARCHAR(30) NOT NULL,
    yearExited DATETIME NOT NULL,
    yearJoined DATETIME NOT NULL,
    eventAttended INT NOT NULL,
    PRIMARY KEY (memberID),
    FOREIGN KEY (eventAttendanceID) REFERENCES EventAttendance(eventAttendanceID),
    FOREIGN KEY (societyID) REFERENCES Society(societyID)
);

CREATE TABLE RSVP (
    rsvpID VARCHAR(30) NOT NULL,
    memberID VARCHAR(30) NOT NULL,
    eventID VARCHAR(30) NOT NULL,
    interest BIT NOT NULL,
    PRIMARY KEY (rsvpID),
    FOREIGN KEY (eventID) REFERENCES Event(eventID),
    FOREIGN KEY (memberID) REFERENCES Member(memberID)
);

CREATE TABLE Student (
    studentID VARCHAR(30) NOT NULL,
    userID VARCHAR(30) NOT NULL,
    studentNumber INT NOT NULL,
    yearOfStudy INT NOT NULL,
    campus VARCHAR(255) NOT NULL,
    PRIMARY KEY (studentID),
    FOREIGN KEY (userID) REFERENCES User(userID)
);
