-- Drop and create the database
DROP DATABASE IF EXISTS managementsociety;
CREATE DATABASE managementsociety;
USE managementsociety;

CREATE TABLE user (
  userID int NOT NULL AUTO_INCREMENT,
  studentN varchar(10) DEFAULT NULL,
  name varchar(255) DEFAULT NULL,
  surname varchar(255) DEFAULT NULL,
  email varchar(255) DEFAULT NULL,
  password varchar(255) DEFAULT NULL,
  PRIMARY KEY (userID)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create Profile table
CREATE TABLE profiless (
  profileID int NOT NULL AUTO_INCREMENT,
  userID int NOT NULL,
  gender varchar(255) NOT NULL,
  race varchar(255) NOT NULL,
  proofOfReg varchar(255) NOT NULL,
  religion varchar(255) NOT NULL,
  hobbies varchar(255) NOT NULL,
  Age varchar(25) DEFAULT NULL,
  Campus varchar(255) NOT NULL,
  PRIMARY KEY (profileID),
  KEY userID (userID),
  CONSTRAINT profiless_ibfk_1 FOREIGN KEY (userID) REFERENCES user (userID)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create Society table
CREATE TABLE society (
    societyID INT AUTO_INCREMENT PRIMARY KEY,
    societyName VARCHAR(255) NOT NULL,
    societyDescription TEXT,
    department VARCHAR(255),
    societyIcon VARCHAR(255),
    societyConstitution VARCHAR(255),
    societyExecutiveList VARCHAR(255),
    societyPetitionList VARCHAR(255),
    societyYearPlan VARCHAR(255),
    societyBudget VARCHAR(255),
    societyPayment VARCHAR(255)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create StudentSociety table
CREATE TABLE studentsociety (
  studentSocietyID INT AUTO_INCREMENT PRIMARY KEY,
  userID INT NOT NULL,
  societyID INT NOT NULL,
  FOREIGN KEY (userID) REFERENCES user (userID),
  FOREIGN KEY (societyID) REFERENCES society (societyID)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create Notices table
CREATE TABLE notices (
  noticeID INT AUTO_INCREMENT PRIMARY KEY,
  societyID INT NOT NULL,
  title varchar(255) NOT NULL,
  content text NOT NULL,
  created_at timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (societyID) REFERENCES society (societyID)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create Requests table
CREATE TABLE requests (
  requestID int NOT NULL AUTO_INCREMENT,
  societyID int NOT NULL,
  userID int NOT NULL,
  requestStatus enum('pending','approved','declined') NOT NULL DEFAULT 'pending',
  requestDate timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (requestID),
  KEY userID (userID),
  KEY societyID (societyID),
  CONSTRAINT requests_ibfk_1 FOREIGN KEY (userID) REFERENCES user (userID),
  CONSTRAINT requests_ibfk_2 FOREIGN KEY (societyID) REFERENCES society (societyID)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create Event table
CREATE TABLE event (
    eventID INT AUTO_INCREMENT PRIMARY KEY,
    societyID INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    eventDate DATETIME NOT NULL,
    eventLocation VARCHAR(255) NOT NULL,
    description VARCHAR(255) NOT NULL,
    eventType VARCHAR(255) NOT NULL,
    preferredVenue VARCHAR(255) NOT NULL,
    preferredTransport VARCHAR(255) NOT NULL,
    eventAmount FLOAT(53) NOT NULL,
    FOREIGN KEY (societyID) REFERENCES society (societyID)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create Meeting table
CREATE TABLE agenda (
  agendaID int NOT NULL AUTO_INCREMENT,
  societyID int NOT NULL,
  meetingName varchar(100) NOT NULL,
  meetingDate datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  meetingVenue varchar(100) DEFAULT NULL,
  meetingAgenda text,
  PRIMARY KEY (agendaID),
  KEY societyID (societyID),
  CONSTRAINT agenda_ibfk_1 FOREIGN KEY (societyID) REFERENCES society (societyID)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create Minutes table
CREATE TABLE minutes (
    minutesID INT NOT NULL AUTO_INCREMENT,
    societyID INT NOT NULL,
    motion VARCHAR(255) NOT NULL,
    PRIMARY KEY (minutesID),
    FOREIGN KEY (societyID) REFERENCES society (societyID)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create AttendanceCode table
CREATE TABLE attendanceCode (
    codeID INT AUTO_INCREMENT PRIMARY KEY,
    eventID INT NOT NULL,
    code VARCHAR(255) NOT NULL UNIQUE,
    FOREIGN KEY (eventID) REFERENCES event (eventID)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create EventAttendance table
CREATE TABLE eventAttendance (
    eventAttendanceID INT AUTO_INCREMENT NOT NULL,
    eventID INT NOT NULL,
    memberID INT NOT NULL,
    code VARCHAR(6) NOT NULL,
    PRIMARY KEY (eventAttendanceID),
    FOREIGN KEY (eventID) REFERENCES event (eventID),
    FOREIGN KEY (memberID) REFERENCES user (userID)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;