class URL {
  // Define the base URLs as static constants
  static const String UJAddress = 'http://10.254.46.24:3006/api'; // UJ Address
  static const String TheCampusAddress = 'http://172.16.31.132:3006/api'; // TheCampus Address
  static const String DefaultAddress = 'http://10.254.157.186:3006/api'; // Default Address  10.254.240.12
  static const String webAPI = 'http://10.254.240.12:3006/api'; // Priscillas ip
  static const String Kea ='http://192.168.43.55:3006/api';

  static String _baseUrl = DefaultAddress;

  static void setBaseUrl(String environment) {
    switch (environment) {
      case 'UJ':
        _baseUrl = UJAddress;
        break;
      case 'WebIP':
        _baseUrl = webAPI;
        break;
      case 'TheCampus':
        _baseUrl = TheCampusAddress;
        break;
      case 'kea':
        _baseUrl = Kea;
        break;
      default:
        _baseUrl = DefaultAddress;
        break;
    }
  }

  // Method to get the current base URL
  static String getBaseUrl() {
    return _baseUrl;
  }
}

/**   

                                          void main() {
                                            // Example usage

                                            URL.setBaseUrl('UJ');
                                            print('Base URL: ${URL.getBaseUrl()}');           // Output: Base URL: http://10.254.46.24:27/api
                                            
                                            URL.setBaseUrl('TheCampus');
                                            print('Base URL: ${URL.getBaseUrl()}');           // Output: Base URL: http://172.16.31.132:27/api
                                            
                                            URL.setBaseUrl('Unknown');
                                            print('Base URL: ${URL.getBaseUrl()}');           // Output: Base URL: http://10.254.157.186:27/api
                                          }

*/