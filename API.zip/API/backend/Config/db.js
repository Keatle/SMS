const mysql=require('mysql2/promise'); 
//creating connection
const connection= mysql.createPool(
    {
        host: 'localhost',
        user: 'root',
        password: 'keatlegile22',
        database: 'managementsociety'

    }

);

//Export
module.exports= connection;