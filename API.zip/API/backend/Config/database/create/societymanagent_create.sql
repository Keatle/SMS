-- Drop and create the database
DROP DATABASE IF EXISTS managementsociety;
CREATE DATABASE managementsociety;
USE managementsociety;

-- Create User table first
CREATE TABLE User (
    userID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    userRole VARCHAR(255) DEFAULT 'student',
    PRIMARY KEY (userID)
);

-- Create Department table
CREATE TABLE Department (
    departmentID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    totalSocieties INT NOT NULL,
    PRIMARY KEY (departmentID)
);

-- Create Society table
CREATE TABLE Society (
    societyID VARCHAR(30) NOT NULL,
    departmentID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    totalMembers INT NOT NULL,
    totalEvents INT NOT NULL,
    active BOOLEAN NOT NULL,
    yearRegistered DATETIME NOT NULL,
    PRIMARY KEY (societyID),
    FOREIGN KEY (departmentID) REFERENCES Department(departmentID)
);

-- Create Event table (change table name from Events to Event for consistency)
CREATE TABLE Event (
    eventID VARCHAR(30) NOT NULL,
    societyID VARCHAR(30) NOT NULL, -- add to api and backend to pull images and make them specific to the
    name VARCHAR(255) NOT NULL,
    eventDate DATETIME NOT NULL,
    eventLocation VARCHAR(255) NOT NULL,
    description VARCHAR(255) NOT NULL,
    eventType VARCHAR(255) NOT NULL,
    preferredVenue VARCHAR(255) NOT NULL,
    preferredTransport VARCHAR(255) NOT NULL,
    eventAmount FLOAT(53) NOT NULL,
    PRIMARY KEY (eventID),
    FOREIGN KEY (societyID) REFERENCES Society(societyID)
);

-- Create Member table
CREATE TABLE Member (
    memberID VARCHAR(30) NOT NULL,
    societyID VARCHAR(30) NOT NULL,
    yearExited DATETIME NOT NULL,
    yearJoined DATETIME NOT NULL,
    eventAttended INT NOT NULL,
    PRIMARY KEY (memberID),
    FOREIGN KEY (societyID) REFERENCES Society(societyID)
);

-- Create AttendanceCode table
CREATE TABLE AttendanceCode (
    codeID INT AUTO_INCREMENT PRIMARY KEY,
    eventID VARCHAR(30) NOT NULL,
    code VARCHAR(255) NOT NULL UNIQUE,
    FOREIGN KEY (eventID) REFERENCES Event(eventID)
);

-- Create EventAttendance table
CREATE TABLE EventAttendance (
    eventAttendanceID  NOT NULL AUTO_INCREMENT,
    eventID VARCHAR(30) NOT NULL,
    memberID VARCHAR(30) NOT NULL,
    code VARCHAR(6) NOT NULL,
    PRIMARY KEY (eventAttendanceID),
    FOREIGN KEY (eventID) REFERENCES Event(eventID),
    FOREIGN KEY (memberID) REFERENCES Member(memberID)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create Admin table
CREATE TABLE Admin (
    adminID VARCHAR(30) NOT NULL,
    yearAppointed DATETIME NOT NULL,
    userID VARCHAR(30) NOT NULL,
    PRIMARY KEY (adminID),
    FOREIGN KEY (userID) REFERENCES User(userID)
);

-- Create SocietyLeader table
CREATE TABLE SocietyLeader (
    societyLeaderID VARCHAR(30) NOT NULL,
    userID VARCHAR(30) NOT NULL,
    position VARCHAR(255) NOT NULL,
    yearAppointed DATETIME NOT NULL,
    PRIMARY KEY (societyLeaderID),
    FOREIGN KEY (userID) REFERENCES User(userID)
);

-- Create Chairperson table
CREATE TABLE Chairperson (
    chairpersonID VARCHAR(30) NOT NULL,
    societyLeaderID VARCHAR(30) NOT NULL,
    PRIMARY KEY (chairpersonID),
    FOREIGN KEY (societyLeaderID) REFERENCES SocietyLeader(societyLeaderID)
);

-- Create Secretary table
CREATE TABLE Secretary (
    secretaryID VARCHAR(30) NOT NULL,
    societyLeaderID VARCHAR(30) NOT NULL,
    PRIMARY KEY (secretaryID),
    FOREIGN KEY (societyLeaderID) REFERENCES SocietyLeader(societyLeaderID)
);

-- Create Application table
CREATE TABLE Application (
    applicationID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    societyName VARCHAR(255) NOT NULL,
    numMembers INT NOT NULL,
    applicationDate DATETIME NOT NULL,
    status VARCHAR(255) NOT NULL,
    active BOOLEAN NOT NULL,
    chairpersonID VARCHAR(30) NOT NULL,
    PRIMARY KEY (applicationID)
);

-- Create Treasurer table
CREATE TABLE Treasurer (
    treasurerID VARCHAR(30) NOT NULL,
    societyLeaderID VARCHAR(30) NOT NULL,
    PRIMARY KEY (treasurerID),
    FOREIGN KEY (societyLeaderID) REFERENCES SocietyLeader(societyLeaderID)
);

-- Create EventBudget table
CREATE TABLE EventBudget (
    eventBudgetID VARCHAR(30) NOT NULL,
    treasurerID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    totalCost FLOAT(53) NOT NULL,
    PRIMARY KEY (eventBudgetID),
    FOREIGN KEY (treasurerID) REFERENCES Treasurer(treasurerID)
);

-- Create Meeting table
CREATE TABLE Agenda (
  agendaID int NOT NULL AUTO_INCREMENT,
  societyID varchar(30) NOT NULL,
  meetingName varchar(100) NOT NULL,
  meetingDate datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  meetingVenue varchar(100) DEFAULT NULL,
  meetingAgenda text,
  PRIMARY KEY (agendaID),
  KEY societyID (societyID),
  CONSTRAINT agenda_ibfk_1 FOREIGN KEY (societyID) REFERENCES societies (SocietyID)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create Minutes table
CREATE TABLE Minutes (
    minutesID INT NOT NULL AUTO_INCREMENT,
    societyID VARCHAR(30) NOT NULL,
    motion VARCHAR(255) NOT NULL,
    proposalReason VARCHAR(255) NOT NULL,
    PRIMARY KEY (minutesID),
    FOREIGN KEY (societyID) REFERENCES Secretary(societyID)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create SocietyBudget table
CREATE TABLE SocietyBudget (
    societyBudgetID VARCHAR(30) NOT NULL,
    treasurerID VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    totalCost FLOAT(53) NOT NULL,
    PRIMARY KEY (societyBudgetID),
    FOREIGN KEY (treasurerID) REFERENCES Treasurer(treasurerID)
);

-- Create Student table
CREATE TABLE Student (
    studentID VARCHAR(30) NOT NULL,
    userID VARCHAR(30) NOT NULL,
    studentNumber INT NOT NULL,
    yearOfStudy INT NOT NULL,
    campus VARCHAR(255) NOT NULL,
    PRIMARY KEY (studentID),
    FOREIGN KEY (userID) REFERENCES User(userID)
);


