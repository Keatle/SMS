package com.example.byte_blossoms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
